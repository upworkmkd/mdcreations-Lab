MD Creations - shadow lamp
Made with MD Creations Labs - labs.themdcreations.com

Seen from the front, with the lamp on the wall:
  1 = top wall, 2 = right wall, 3 = left wall (switch side), 4 = bottom wall.

Print: flat, as oriented in the files (outer face on the bed), opaque filament, no supports.
Pieces that stand up from a wall belong to the corner and print with it.

Assemble: long walls (2 and 3) first, then the short ones (1 and 4). Screw each wall to the base (M2.5 x 8 self-tapping).

Cover plate: lies on the rim of the base between the walls, with the post through its hole.
Print the plate with the sunk side up. Print the plate picture flat in a second colour and press each piece into its place.

Base and battery cover: the same for every design. Print the base with its back on the bed, no supports;
print the cover with its wider face down. It takes a 2 x AA holder and a small rocker switch.

LED post: print it standing on its notched end with a brim, no supports. It is 79 mm long and puts the LED
82 mm out from the wall, where this design expects the light. Push the narrow end into the socket in the middle of the base
until the collar sits on top, turning it so the notch at its foot lines up with the slot at the foot of the socket.
Use a 5 mm LED (warm white looks best): feed its wires down the hole in the post; they come out through the notch and the slot
to the battery holder and switch. The LED rim rests on the top of the post.

FREE SAMPLE: see SAMPLE-NOTICE.txt. Make your own lamp at labs.themdcreations.com
